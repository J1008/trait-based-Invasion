############################        补充计算 平均功能距离Xu M, Li S, Dick J T A, Et Al. 
###################Exotic Fishes That Are Phylogenetically Close But Functionally Distant To Native Fishes Are More Likely To Establish[J]. 
#################Global Change Biology, 2022, 28(19): 5683-5694.
############################
#############################################

# 载入必要的库
library(dplyr)
library(openxlsx) # 用于保存数据到xlsx文件

# 2. 读取rawdata文件夹中的所有CSV文件并合并
files <- list.files(path = "rawdata", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 3. 去重，假设'name'列包含物种名
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)

# 2. 预处理数据
# 假设第一列是物种名，我们将其排除在距离计算之外
trait_data <- distinct_data[, -1]

# 3. 计算距离矩阵
dist_matrix <- dist(trait_data, method = "euclidean")

# 转换为完整的方形矩阵
dist_matrix_full <- as.matrix(dist_matrix)
# 设置行和列名称
rownames(dist_matrix_full) <- colnames(dist_matrix_full) <- distinct_data$name
# 假设dist_matrix_full是距离矩阵，其行列名称与distinct_data中的物种名称一致
species_names <- rownames(dist_matrix_full)  # 或 distinct_data$name

# 提取“——”之前的部分
short_names <- sub("^(.*?)——.*", "\\1", species_names)

# 确保新名称的顺序与原始数据一致
rownames(dist_matrix_full) <- colnames(dist_matrix_full) <- short_names

dist_matrix <- dist_matrix_full

# 获取所有CSV文件
csv_files <- list.files(path = "rawdata", pattern = "*.csv", full.names = TRUE)

# 创建结果文件夹（如果不存在）
result_dir <- "Function"
if (!dir.exists(result_dir)) {
  dir.create(result_dir)
}

# 定义处理单个文件的函数，分阶段计算功能距离，包括 his-his
process_file <- function(files, dist_matrix, group_data) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并处理物种名称
    df <- read.csv(file)
    df$species <- gsub("^(.*)——.*$", "\\1", df$name)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)
    df$period <- period
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              Distance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的功能距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]$species
      for (i in 1:(length(his_species) - 1)) {
        for (j in (i + 1):length(his_species)) {
          species1 <- his_species[i]
          species2 <- his_species[j]
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix)) {
            distance <- dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[["his"]]$name[species_data[["his"]]$species == species1]
            full_species2 <- species_data[["his"]]$name[species_data[["his"]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             Distance = distance, Location = location, Stage = "his",
                                                             ComparisonType = "his-his"))
          }
        }
      }
    }
    
    # 2. 分阶段进行分析：his-mid 和 mid-late
    stages <- list("his-mid" = c("his", "mid"), "mid-late" = c("mid", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1]
      period2 <- stages[[stage]][2]
      
      # 获取前一个时期（period1）和后一个时期（period2）的物种
      species_period1 <- species_data[[period1]]$species
      species_period2 <- species_data[[period2]]$species
      
      # 定义物种类别
      retained_species <- intersect(species_period1, species_period2)
      newly_established_species <- setdiff(species_period2, species_period1)
      extirpated_species <- setdiff(species_period1, species_period2)
      
      # 计算功能距离并添加到结果数据框中
      # 1. 新增物种与保留物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2 in retained_species) {
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix)) {
            distance <- dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             Distance = distance, Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Retained"))
          }
        }
      }
      
      # 2. 新增物种与消失物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix)) {
            distance <- dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             Distance = distance, Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Extirpated"))
          }
        }
      }
      
      # 3. 新增物种与消失的“本土”物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix)) {
            # 确保 species2 是“本土”物种
            species2_status <- species_data[[period1]]$status[species_data[[period1]]$species == species2]
            if (species2_status == "native") {
              distance <- dist_matrix[species1, species2]
              full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
              full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
              final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                               Distance = distance, Location = location, Stage = stage,
                                                               ComparisonType = "Newly-Established vs Extirpated Native"))
            }
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}


# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, dist_matrix)

# 将结果保存到CSV文件中
write.csv(final_results, "Functional_distance_comparison.csv", row.names = FALSE)
write.xlsx(final_results, "Functional_distance_comparison.xlsx", rowNames = FALSE)


# 使用 dplyr 计算平均功能距离
mean_distances <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(Distance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到xlsx文件中
write.xlsx(mean_distances, "Mean_functional_distance_comparison.xlsx", rowNames = FALSE)



############################
############################        补充计算平均系统发育距离Li S, Cadotte M W, Meiners S J, et al.
#################################   The effects of phylogenetic relatedness on invasion success and impact: 
###############################deconstructing Darwin's naturalisation conundrum[J]. Ecology letters, 2015, 18(12): 1285-1292.
############################
#############################################
# 载入必要的库
library(dplyr)
library(ape)      # 用于读取系统发育树和计算系统发育距离
library(openxlsx) # 用于保存数据到xlsx文件

# 读取系统发育树文件并生成系统发育距离矩阵
phylo_tree <- read.tree("phylo_tree.newick")
phylo_dist_matrix <- cophenetic(phylo_tree)

# 定义处理单个文件的函数，分阶段计算系统发育距离
process_file <- function(files, phylo_dist_matrix) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并处理物种名称
    df <- read.csv(file)
    df$species <- gsub("^(.*)——.*$", "\\1", df$name)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)
    df$period <- period
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              PhylogeneticDistance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的系统发育距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]$species
      for (i in 1:(length(his_species) - 1)) {
        for (j in (i + 1):length(his_species)) {
          species1 <- his_species[i]
          species2 <- his_species[j]
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[["his"]]$name[species_data[["his"]]$species == species1]
            full_species2 <- species_data[["his"]]$name[species_data[["his"]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = "his",
                                                             ComparisonType = "his-his"))
          }
        }
      }
    }
    
    # 2. 分阶段进行分析：his-mid 和 mid-late
    stages <- list("his-mid" = c("his", "mid"), "mid-late" = c("mid", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1]
      period2 <- stages[[stage]][2]
      
      # 获取前一个时期（period1）和后一个时期（period2）的物种
      species_period1 <- species_data[[period1]]$species
      species_period2 <- species_data[[period2]]$species
      
      # 定义物种类别
      retained_species <- intersect(species_period1, species_period2)
      newly_established_species <- setdiff(species_period2, species_period1)
      extirpated_species <- setdiff(species_period1, species_period2)
      
      # 计算系统发育距离并添加到结果数据框中
      # 1. 新增物种与保留物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in retained_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Retained"))
          }
        }
      }
      
      # 2. 新增物种与消失物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Extirpated"))
          }
        }
      }
      
      # 3. 新增物种与消失的“本土”物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            # 确保 species2 是“本土”物种
            species2_status <- species_data[[period1]]$status[species_data[[period1]]$species == species2]
            if (species2_status == "native") {
              phylo_distance <- phylo_dist_matrix[species1, species2]
              full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
              full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
              final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                               PhylogeneticDistance = phylo_distance,
                                                               Location = location, Stage = stage,
                                                               ComparisonType = "Newly-Established vs Extirpated Native"))
            }
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, phylo_dist_matrix)

# 将结果保存到CSV文件中
write.csv(final_results, "Phylogenetic_distance_comparison.csv", row.names = FALSE)
write.xlsx(final_results, "Phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

# 使用 dplyr 计算平均系统发育距离
mean_distances <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(PhylogeneticDistance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到xlsx文件中
write.xlsx(mean_distances, "Mean_phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

############################
############################        原本的计算平均系统发育距离（新的系统发育树）Li S, Cadotte M W, Meiners S J, et al.
#################################   The effects of phylogenetic relatedness on invasion success and impact: 
###############################deconstructing Darwin's naturalisation conundrum[J]. Ecology letters, 2015, 18(12): 1285-1292.
############################
#############################################

# 载入必要的库
library(dplyr)
library(ape)      # 用于读取系统发育树和计算系统发育距离
library(openxlsx) # 用于保存数据到xlsx文件

# 读取系统发育树文件并生成系统发育距离矩阵
phylo_tree <- read.tree("phylo_tree.newick")
phylo_dist_matrix <- cophenetic(phylo_tree)

process_file <- function(files, phylo_dist_matrix) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并处理物种名称
    df <- read.csv(file)
    df$species <- gsub("^(.*)——.*$", "\\1", df$name)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)
    df$period <- period
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              PhylogeneticDistance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的系统发育距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]$species
      for (i in 1:(length(his_species) - 1)) {
        for (j in (i + 1):length(his_species)) {
          species1 <- his_species[i]
          species2 <- his_species[j]
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[["his"]]$name[species_data[["his"]]$species == species1]
            full_species2 <- species_data[["his"]]$name[species_data[["his"]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = "his",
                                                             ComparisonType = "his-his"))
          }
        }
      }
    }
    
    # 2. 分阶段进行分析：his-mid 和 his-late
    stages <- list("his-mid" = c("his", "mid"), "his-late" = c("his", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1] # "his"
      period2 <- stages[[stage]][2] # "mid" 或 "late"
      
      # 获取时期的物种
      his_native_species <- species_data[[period1]] %>% filter(status == "native") %>% pull(species)
      current_native_species <- species_data[[period2]] %>% filter(status == "native") %>% pull(species)
      current_non_species <- species_data[[period2]] %>% filter(status == "non") %>% pull(species)
      
      # 计算系统发育距离并添加到结果数据框中
      # 1. current 非本土物种与 current 本土物种的距离
      for (species1 in current_non_species) {
        for (species2 in current_native_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period2]]$name[species_data[[period2]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-retainednative"))
          }
        }
      }
      
      # 2. current 非本土物种与 his 本土物种的距离
      for (species1 in current_non_species) {
        for (species2 in his_native_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-hisnative"))
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, phylo_dist_matrix)

# 将结果保存到CSV文件中
write.csv(final_results, "original-Phylogenetic_distance_comparison.csv", row.names = FALSE)
write.xlsx(final_results, "original-Phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

# 使用 dplyr 计算平均系统发育距离
mean_distances <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(PhylogeneticDistance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到xlsx文件中
write.xlsx(mean_distances, "original-Mean_phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

############################
############################      原本的网络余弦距离的计算
############################
#############################################
# 加载必要的库
library(dplyr)
library(openxlsx) # 用于保存数据到xlsx文件
library(readxl)   # 用于读取xlsx文件
library(proxy)

# 读取物种分组信息
group_data <- read_excel("group/clustering_result.xlsx")

# 读取并处理物种数据，计算网络余弦距离
files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 去重处理
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
distinct_data$Keratin[distinct_data$Keratin == 0.001] <- 0
distinct_data <- distinct_data %>% mutate(across(-name, scale))  # 标准化

# 计算余弦相似度矩阵并转化为距离矩阵
trait_data <- distinct_data[, -1]
similarity <- proxy::simil(trait_data, method = "cosine")
similarity <- as.matrix(similarity)
rownames(similarity) <- distinct_data$name
colnames(similarity) <- distinct_data$name
network_cosine_distance <- 1 - similarity

# 函数：处理每个文件并生成结果
process_network_distance <- function(files, network_distance_matrix, group_data) {
  results_list <- list()
  
  # 遍历所有文件
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并直接使用 `name` 列
    df <- read.csv(file)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)  # 提取状态信息
    df$period <- period
    
    # 将物种数据与分组信息合并
    df <- df %>% left_join(group_data, by = "name")
    print(paste("Processing:", location, period, "with rows:", nrow(df)))  # 调试输出
    
    # 将数据按地点存储
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化结果数据框
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              NetworkCosineDistance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character(), Group = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的网络余弦距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]
      for (i in 1:(nrow(his_species) - 1)) {
        for (j in (i + 1):nrow(his_species)) {
          species1 <- his_species$name[i]
          species2 <- his_species$name[j]
          group1 <- his_species$group[i]
          group2 <- his_species$group[j]
          
          # 调试输出
          print(paste("Comparing species:", species1, species2, "Group1:", group1, "Group2:", group2))
          
          # 仅当两个物种属于相同组别时进行计算
          if (species1 %in% rownames(network_distance_matrix) && species2 %in% colnames(network_distance_matrix) && group1 == group2) {
            network_distance <- network_distance_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             NetworkCosineDistance = network_distance,
                                                             Location = location, Stage = "his",
                                                             ComparisonType = "his-his", Group = group1))
          }
        }
      }
    }
    
    # 2. 分阶段分析：his-mid 和 his-late
    stages <- list("his-mid" = c("his", "mid"), "his-late" = c("his", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1]
      period2 <- stages[[stage]][2]
      
      # 获取物种
      his_native_species <- species_data[[period1]] %>% filter(status == "native")
      current_native_species <- species_data[[period2]] %>% filter(status == "native")
      current_non_species <- species_data[[period2]] %>% filter(status == "non")
      
      # 计算距离并添加到结果数据框
      # 1. current 非本土物种与 current 本土物种的距离
      for (species1_row in 1:nrow(current_non_species)) {
        species1 <- current_non_species$name[species1_row]
        group1 <- current_non_species$group[species1_row]
        
        for (species2_row in 1:nrow(current_native_species)) {
          species2 <- current_native_species$name[species2_row]
          group2 <- current_native_species$group[species2_row]
          
          # 调试输出
          print(paste("Comparing species:", species1, species2, "Group1:", group1, "Group2:", group2))
          
          if (species1 %in% rownames(network_distance_matrix) && species2 %in% colnames(network_distance_matrix) && group1 == group2) {
            network_distance <- network_distance_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             NetworkCosineDistance = network_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-retainednative", Group = group1))
          }
        }
      }
      
      # 2. current 非本土物种与 his 本土物种的距离
      for (species1_row in 1:nrow(current_non_species)) {
        species1 <- current_non_species$name[species1_row]
        group1 <- current_non_species$group[species1_row]
        
        for (species2_row in 1:nrow(his_native_species)) {
          species2 <- his_native_species$name[species2_row]
          group2 <- his_native_species$group[species2_row]
          
          # 调试输出
          print(paste("Comparing species:", species1, species2, "Group1:", group1, "Group2:", group2))
          
          if (species1 %in% rownames(network_distance_matrix) && species2 %in% colnames(network_distance_matrix) && group1 == group2) {
            network_distance <- network_distance_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             NetworkCosineDistance = network_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-hisnative", Group = group1))
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_network_distance(csv_files, network_cosine_distance, group_data)

# 将结果保存到CSV和XLSX文件中
write.csv(final_results, "network-fucntional_distance_comparison_with_group.csv", row.names = FALSE)
write.xlsx(final_results, "network-fucntiona_distance_comparison_with_group.xlsx", rowNames = FALSE)

# 加载必要的库
library(dplyr)
library(openxlsx)

# 使用 dplyr 计算按 Group 分组的平均网络余弦距离
mean_distances_grouped <- final_results %>%
  group_by(Location, Stage, ComparisonType, Group) %>%
  summarise(mean_distance = mean(NetworkCosineDistance, na.rm = TRUE)) %>%
  ungroup()

# 使用 dplyr 计算不按 Group 分组的平均网络余弦距离
mean_distances_all <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(NetworkCosineDistance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到同一个xlsx文件的不同工作表
write.xlsx(list(grouped = mean_distances_grouped, all = mean_distances_all),
           "network-Mean_functional_distance_comparison_with_group.xlsx",
           rowNames = FALSE)

############################
############################      补充的网络余弦距离的计算
############################
#############################################
# 加载必要的库
library(dplyr)
library(openxlsx) # 用于保存数据到xlsx文件
library(readxl)   # 用于读取分组信息
library(proxy)    # 用于计算余弦距离

# 读取物种分组信息
group_data <- read_excel("group/clustering_result.xlsx")

# 读取并处理物种数据，计算网络余弦距离
files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 去重处理
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
distinct_data$Keratin[distinct_data$Keratin == 0.001] <- 0
distinct_data <- distinct_data %>% mutate(across(-name, scale))  # 标准化

# 计算余弦相似度矩阵并转化为距离矩阵
trait_data <- distinct_data[, -1]
similarity <- proxy::simil(trait_data, method = "cosine")
similarity <- as.matrix(similarity)
rownames(similarity) <- distinct_data$name
colnames(similarity) <- distinct_data$name

network_cosine_distance <- 1-similarity

# 定义处理单个文件的函数，分阶段计算功能距离，包括 his-his
process_file <- function(files, dist_matrix, group_data) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并直接使用 `name` 列
    df <- read.csv(file)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)  # 提取状态信息
    df$period <- period
    
    # 将物种数据与分组信息合并
    df <- df %>% left_join(group_data, by = "name")
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              Distance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character(), Group = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的功能距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]
      for (i in 1:(nrow(his_species) - 1)) {
        for (j in (i + 1):nrow(his_species)) {
          species1 <- his_species$name[i]
          species2 <- his_species$name[j]
          group1 <- his_species$group[i]
          group2 <- his_species$group[j]
          
          # 仅当两个物种属于相同组别时计算距离
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix) && group1 == group2) {
            distance <- dist_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             Distance = distance, Location = location, Stage = "his",
                                                             ComparisonType = "his-his", Group = group1))
          }
        }
      }
    }
    
    # 2. 分阶段分析：his-mid 和 mid-late
    stages <- list("his-mid" = c("his", "mid"), "mid-late" = c("mid", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1]
      period2 <- stages[[stage]][2]
      
      # 获取前一个时期（period1）和后一个时期（period2）的物种
      species_period1 <- species_data[[period1]]
      species_period2 <- species_data[[period2]]
      
      # 定义物种类别
      retained_species <- intersect(species_period1$name, species_period2$name)
      newly_established_species <- setdiff(species_period2$name, species_period1$name)
      extirpated_species <- setdiff(species_period1$name, species_period2$name)
      
      # 计算功能距离并添加到结果数据框中
      # 1. 新增物种与保留物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2 in retained_species) {
          group1 <- species_period2$group[species_period2$name == species1]
          group2 <- species_period1$group[species_period1$name == species2]
          
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix) && group1 == group2) {
            distance <- dist_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             Distance = distance, Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Retained", Group = group1))
          }
        }
      }
      
      # 2. 新增物种与消失物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          group1 <- species_period2$group[species_period2$name == species1]
          group2 <- species_period1$group[species_period1$name == species2]
          
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix) && group1 == group2) {
            distance <- dist_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             Distance = distance, Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Extirpated", Group = group1))
          }
        }
      }
      
      # 3. 新增物种与消失的“本土”物种之间的功能距离
      for (species1 in newly_established_species) {
        for (species2_row in 1:nrow(species_period1)) {
          species2 <- species_period1$name[species2_row]
          group1 <- species_period2$group[species_period2$name == species1]
          group2 <- species_period1$group[species_period1$name == species2]
          
          # 仅当 species2 是“本土”物种（status == "native"）且在相同组时计算
          if (species1 %in% rownames(dist_matrix) && species2 %in% colnames(dist_matrix) &&
              species_period1$status[species2_row] == "native" && group1 == group2) {
            distance <- dist_matrix[species1, species2]
            final_results <- rbind(final_results, data.frame(Species1 = species1, Species2 = species2, 
                                                             Distance = distance, Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Extirpated Native", Group = group1))
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, network_cosine_distance, group_data)

# 将结果保存到CSV和XLSX文件中
write.csv(final_results, "network-functional_distance_comparison_with_group.csv", row.names = FALSE)
write.xlsx(final_results, "network-functional_distance_comparison_with_group.xlsx", rowNames = FALSE)

# 计算平均功能距离
mean_distances_grouped <- final_results %>%
  group_by(Location, Stage, ComparisonType, Group) %>%
  summarise(mean_distance = mean(Distance, na.rm = TRUE)) %>%
  ungroup()

mean_distances_all <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(Distance, na.rm = TRUE)) %>%
  ungroup()

# 保存平均距离到同一个文件的不同工作表
write.xlsx(list(grouped = mean_distances_grouped, all = mean_distances_all),
           "network-Mean_functional_distance_comparison_with_group.xlsx", rowNames = FALSE)




#########参数作图########
# 加载必要的库
# 加载必要的库
library(openxlsx)   # 用于读取 .xlsx 文件
library(ggplot2)    # 用于绘图
library(broom)      # 用于提取模型统计信息
library(dplyr)      # 用于数据处理
library(stringr)    # 用于处理字符串

# 读取xlsx文件
file_path <- "newtree_Newly-Established vs Retained.xlsx"
data <- read.xlsx(file_path)

# 提取文件名并作为标题
plot_title <- str_remove(basename(file_path), "\\.xlsx$")

# 显示文件的列名
print("文件的列名:")
print(colnames(data))

# 请指定 x 轴和 y 轴的列名
x_col <- "LoI"
y_col <- "corrected_mean_distance"

# 转换列为数值类型（如果需要）
data[[x_col]] <- as.numeric(data[[x_col]])
data[[y_col]] <- as.numeric(data[[y_col]])

# 创建散点图，添加二次拟合曲线和置信区间
plot <- ggplot(data, aes_string(x = x_col, y = y_col)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ poly(x, 2), se = TRUE, color = "blue") +
  labs(x = x_col, y = y_col, title = plot_title) +
  theme_minimal() +
  theme(
    # 添加坐标框线
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    # 去掉网格线
    panel.grid = element_blank(),
    # 增加坐标轴刻度
    axis.ticks = element_line(color = "black"),
    # 设置标题样式
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold")
  )

# 拟合二次项模型
model <- lm(as.formula(paste(y_col, "~ poly(", x_col, ", 2)")), data = data)
model_summary <- summary(model)

# 提取R值、R²和P值
r_squared <- model_summary$r.squared
r_value <- sqrt(r_squared)
anova_result <- anova(model)
overall_p_value <- anova_result$"Pr(>F)"[1]

# 获取模型系数
coefficients <- coef(model)

# 创建方程文本
equation_text <- paste0("y = ", round(coefficients[1], 2), " + ",
                        round(coefficients[2], 2), "x + ",
                        round(coefficients[3], 2), "x²")
statistics_text <- paste0("R = ", round(r_value, 2), 
                          ", R² = ", round(r_squared, 2),
                          ", p = ", ifelse(overall_p_value < 0.05, "< 0.05", round(overall_p_value, 2)))

# 在图上添加方程、R值、R²和P值
plot <- plot +
  annotate("text", x = Inf, y = Inf, label = equation_text, hjust = 1.1, vjust = 2, size = 4, color = "blue", parse = FALSE) +
  annotate("text", x = Inf, y = Inf, label = statistics_text, hjust = 1.1, vjust = 3.5, size = 4, color = "blue", parse = FALSE)

# 显示图形
print(plot)

########各个地点链接####
# 加载必要的库
library(openxlsx)   # 用于读取 .xlsx 文件
library(ggplot2)    # 用于绘图
library(dplyr)      # 用于数据处理
library(stringr)    # 用于处理字符串

# 读取xlsx文件
file_path <- "newtree_non-retainednative.xlsx"
data <- read.xlsx(file_path)

# 提取文件名并作为标题
plot_title <- str_remove(basename(file_path), "\\.xlsx$")
# 显示文件的列名
print("文件的列名:")
print(colnames(data))

# 请指定 x 轴和 y 轴的列名
x_col <- "LoI"
y_col <- "Corrected_mean_distance"


# 转换列为数值类型
data[[x_col]] <- as.numeric(data[[x_col]])
data[[y_col]] <- as.numeric(data[[y_col]])

# 绘制散点图并添加整体的二次项拟合曲线（包含置信区间）
plot <- ggplot(data, aes_string(x = x_col, y = y_col)) +
  geom_point(size = 2) +  # 调整点的大小
  geom_smooth(method = "lm", formula = y ~ poly(x, 2), se = TRUE, color = "blue") +  # 整体拟合曲线
  labs(x = x_col, y = y_col, title = plot_title) +  # 自动标题
  theme_minimal() +
  theme(
    # 添加坐标框线
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    # 去掉网格线
    panel.grid = element_blank(),
    # 增加坐标轴刻度
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(color = "black"),  # 坐标轴刻度颜色
    # 设置标题样式
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold")
  )

# 为每个地点添加浅灰色的二次项连接曲线
for (location in unique(data$Location)) {
  subset_data <- data %>% filter(Location == location)
  
  # 使用 stat_smooth 生成每个地点的二次项连接
  plot <- plot + stat_smooth(data = subset_data, aes(x = !!sym(x_col), y = !!sym(y_col)), 
                             method = "lm", formula = y ~ poly(x, 2), se = FALSE, color = "lightgrey", linetype = "solid")
}

# 拟合整体的二次项模型
model <- lm(as.formula(paste(y_col, "~ poly(", x_col, ", 2)")), data = data)
model_summary <- summary(model)

# 提取R值、R²和P值
r_squared <- model_summary$r.squared
r_value <- sqrt(r_squared)
anova_result <- anova(model)
overall_p_value <- anova_result$"Pr(>F)"[1]

# 获取模型系数
coefficients <- coef(model)

# 创建方程和统计信息文本
equation_text <- paste0("y = ", round(coefficients[1], 2), " + ",
                        round(coefficients[2], 2), "x + ",
                        round(coefficients[3], 2), "x²")
statistics_text <- paste0("R = ", round(r_value, 2), 
                          ", R² = ", round(r_squared, 2),
                          ", p = ", ifelse(overall_p_value < 0.05, "< 0.05", round(overall_p_value, 2)))

# 在图上添加方程、R值、R²和P值
plot <- plot +
  annotate("text", x = Inf, y = Inf, label = equation_text, hjust = 1.1, vjust = 2, size = 4, color = "blue", parse = FALSE) +
  annotate("text", x = Inf, y = Inf, label = statistics_text, hjust = 1.1, vjust = 3.5, size = 4, color = "blue", parse = FALSE)

# 显示图形
print(plot)



############################
############################    使用分类学距离代替   原有   系统发育距离进行计算Jia et al., (2020). 
#######           Human disturbance and long-term changes in fish taxonomic, functional and phylogenetic diversity in the Yellow River, China. 
################         Hydrobiologia
############################
#############################################

# load("taxa_info.RData")
# taxa_data <- taxa_info$All_info_fishbase[, c("user_spp", "Family", "Order", "Class", "SuperClass")]
# write.xlsx(taxa_data, "taxa_data.xlsx")
taxa_data <- read.xlsx("taxa_data.xlsx")
rownames(taxa_data) <- taxa_data[, 1]
taxdis <- taxa2dist(taxa_data, varstep=TRUE)
phylo_dist_matrix <- as.matrix(taxdis)

process_file <- function(files, phylo_dist_matrix) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并处理物种名称
    df <- read.csv(file)
    df$species <- gsub("^(.*)——.*$", "\\1", df$name)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)
    df$period <- period
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              PhylogeneticDistance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的系统发育距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]$species
      for (i in 1:(length(his_species) - 1)) {
        for (j in (i + 1):length(his_species)) {
          species1 <- his_species[i]
          species2 <- his_species[j]
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[["his"]]$name[species_data[["his"]]$species == species1]
            full_species2 <- species_data[["his"]]$name[species_data[["his"]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = "his",
                                                             ComparisonType = "his-his"))
          }
        }
      }
    }
    
    # 2. 分阶段进行分析：his-mid 和 his-late
    stages <- list("his-mid" = c("his", "mid"), "his-late" = c("his", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1] # "his"
      period2 <- stages[[stage]][2] # "mid" 或 "late"
      
      # 获取时期的物种
      his_native_species <- species_data[[period1]] %>% filter(status == "native") %>% pull(species)
      current_native_species <- species_data[[period2]] %>% filter(status == "native") %>% pull(species)
      current_non_species <- species_data[[period2]] %>% filter(status == "non") %>% pull(species)
      
      # 计算系统发育距离并添加到结果数据框中
      # 1. current 非本土物种与 current 本土物种的距离
      for (species1 in current_non_species) {
        for (species2 in current_native_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period2]]$name[species_data[[period2]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-retainednative"))
          }
        }
      }
      
      # 2. current 非本土物种与 his 本土物种的距离
      for (species1 in current_non_species) {
        for (species2 in his_native_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "non-hisnative"))
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, phylo_dist_matrix)

# 将结果保存到CSV文件中
write.csv(final_results, "original-Phylogenetic_distance_comparison.csv", row.names = FALSE)
write.xlsx(final_results, "original-Phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

# 使用 dplyr 计算平均系统发育距离
mean_distances <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(PhylogeneticDistance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到xlsx文件中
write.xlsx(mean_distances, "new tree-original-Mean_phylogenetic_distance_comparison.xlsx", rowNames = FALSE)


############################
############################    使用分类学距离代替    补充   系统发育距离进行计算Jia et al., (2020). 
#######           Human disturbance and long-term changes in fish taxonomic, functional and phylogenetic diversity in the Yellow River, China. 
################         Hydrobiologia
############################
#############################################
# 载入必要的库
library(dplyr)
library(ape)      # 用于读取系统发育树和计算系统发育距离
library(openxlsx) # 用于保存数据到xlsx文件
# load("taxa_info.RData")
# taxa_data <- taxa_info$All_info_fishbase[, c("user_spp", "Family", "Order", "Class", "SuperClass")]
# write.xlsx(taxa_data, "taxa_data.xlsx")
taxa_data <- read.xlsx("taxa_data.xlsx")
rownames(taxa_data) <- taxa_data[, 1]
taxdis <- taxa2dist(taxa_data, varstep=TRUE)
phylo_dist_matrix <- as.matrix(taxdis)

# 定义处理单个文件的函数，分阶段计算系统发育距离
process_file <- function(files, phylo_dist_matrix) {
  results_list <- list()
  
  # 遍历所有文件，并从文件名提取地点和时期
  for (file in files) {
    parts <- strsplit(basename(file), "——")[[1]]
    location <- parts[1]
    period <- gsub("\\.csv$", "", parts[2])
    
    # 读取物种数据并处理物种名称
    df <- read.csv(file)
    df$species <- gsub("^(.*)——.*$", "\\1", df$name)
    df$status <- gsub("^.*——(.*)$", "\\1", df$name)
    df$period <- period
    
    # 将数据按地点存储，以便后续按阶段处理
    if (!is.list(results_list[[location]])) {
      results_list[[location]] <- list()
    }
    results_list[[location]][[period]] <- df
  }
  
  # 初始化一个数据框存储最终结果
  final_results <- data.frame(Species1 = character(), Species2 = character(), 
                              PhylogeneticDistance = numeric(), Location = character(), Stage = character(),
                              ComparisonType = character())
  
  # 遍历每个地点的各阶段
  for (location in names(results_list)) {
    species_data <- results_list[[location]]
    
    # 1. 计算 his 时期的同类物种之间的系统发育距离
    if ("his" %in% names(species_data)) {
      his_species <- species_data[["his"]]$species
      for (i in 1:(length(his_species) - 1)) {
        for (j in (i + 1):length(his_species)) {
          species1 <- his_species[i]
          species2 <- his_species[j]
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[["his"]]$name[species_data[["his"]]$species == species1]
            full_species2 <- species_data[["his"]]$name[species_data[["his"]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = "his",
                                                             ComparisonType = "his-his"))
          }
        }
      }
    }
    
    # 2. 分阶段进行分析：his-mid 和 mid-late
    stages <- list("his-mid" = c("his", "mid"), "mid-late" = c("mid", "late"))
    for (stage in names(stages)) {
      period1 <- stages[[stage]][1]
      period2 <- stages[[stage]][2]
      
      # 获取前一个时期（period1）和后一个时期（period2）的物种
      species_period1 <- species_data[[period1]]$species
      species_period2 <- species_data[[period2]]$species
      
      # 定义物种类别
      retained_species <- intersect(species_period1, species_period2)
      newly_established_species <- setdiff(species_period2, species_period1)
      extirpated_species <- setdiff(species_period1, species_period2)
      
      # 计算系统发育距离并添加到结果数据框中
      # 1. 新增物种与保留物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in retained_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Retained"))
          }
        }
      }
      
      # 2. 新增物种与消失物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            phylo_distance <- phylo_dist_matrix[species1, species2]
            # 使用完整物种名
            full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
            full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
            final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                             PhylogeneticDistance = phylo_distance,
                                                             Location = location, Stage = stage,
                                                             ComparisonType = "Newly-Established vs Extirpated"))
          }
        }
      }
      
      # 3. 新增物种与消失的“本土”物种之间的系统发育距离
      for (species1 in newly_established_species) {
        for (species2 in extirpated_species) {
          if (species1 %in% rownames(phylo_dist_matrix) && species2 %in% colnames(phylo_dist_matrix)) {
            # 确保 species2 是“本土”物种
            species2_status <- species_data[[period1]]$status[species_data[[period1]]$species == species2]
            if (species2_status == "native") {
              phylo_distance <- phylo_dist_matrix[species1, species2]
              full_species1 <- species_data[[period2]]$name[species_data[[period2]]$species == species1]
              full_species2 <- species_data[[period1]]$name[species_data[[period1]]$species == species2]
              final_results <- rbind(final_results, data.frame(Species1 = full_species1, Species2 = full_species2, 
                                                               PhylogeneticDistance = phylo_distance,
                                                               Location = location, Stage = stage,
                                                               ComparisonType = "Newly-Established vs Extirpated Native"))
            }
          }
        }
      }
    }
  }
  
  # 返回最终计算结果
  return(final_results)
}

# 主执行部分，按地点和阶段保存结果
csv_files <- list.files(path = "rawdata_ori", pattern = "\\.csv$", full.names = TRUE)
final_results <- process_file(csv_files, phylo_dist_matrix)

# 将结果保存到CSV文件中
write.csv(final_results, "Phylogenetic_distance_comparison.csv", row.names = FALSE)
write.xlsx(final_results, "Phylogenetic_distance_comparison.xlsx", rowNames = FALSE)

# 使用 dplyr 计算平均系统发育距离
mean_distances <- final_results %>%
  group_by(Location, Stage, ComparisonType) %>%
  summarise(mean_distance = mean(PhylogeneticDistance, na.rm = TRUE)) %>%
  ungroup()

# 将结果保存到xlsx文件中
write.xlsx(mean_distances, "newtree_Mean_phylogenetic_distance_comparison.xlsx", rowNames = FALSE)


###########   功能组特征分析 #####
# 加载必要的库
library(dplyr)
library(vegan)
library(readxl)
library(labdsv)
library(reshape2)
library(ggplot2)
library(openxlsx)


# 1. 读取功能性状数据
files <- list.files(path = "rawdata", pattern = "\\.csv$", full.names = TRUE)
all_data <- lapply(files, read.csv, header = TRUE) %>% bind_rows()

# 2. 去重，假设 'name' 列包含物种名
distinct_data <- all_data %>% distinct(name, .keep_all = TRUE)
distinct_data$Keratin[distinct_data$Keratin == 0.001] <- 0
distinct_data <- distinct_data %>% mutate(across(-name, scale))  # 标准化

# 3. 提取功能性状数据，去除物种名和分组列
# 将物种名作为行名
rownames(distinct_data) <- distinct_data$name
trait_data <- distinct_data[, -1]  # 去除物种名列

# 4. 读取分组数据
group_data <- read_excel("group/clustering_result.xlsx")

# 将物种数据与分组信息合并，确保两者对齐
trait_data <- trait_data %>% filter(rownames(trait_data) %in% group_data$name)
group_data <- group_data %>% filter(name %in% rownames(trait_data))

# 转换分组信息为因子
groups <- as.factor(group_data$group)

# 5. 检查并去除缺失值
# 确保 trait_data 没有 NA
trait_data <- na.omit(trait_data)

# 6. 使用指示物种分析（指示性功能性状分析）
indval_result <- indval(as.matrix(trait_data), groups)


# 提取指示性分析结果并转换为长格式
indval_long <- as.data.frame(indval_result[["indval"]])
indval_long$Trait <- rownames(indval_long)
indval_melt <- melt(indval_long, id.vars = "Trait", variable.name = "Group", value.name = "IndVal")

# 获取所有 Trait 的名称，并将指定的性状置于开头
all_traits <- unique(indval_melt$Trait)
# 指定性状顺序，确保 Troph、a、b 在顶部，Logarithm.of.must、Keratin、stab 在底部
ordered_traits <- c("Logarithm.of.must", "Keratin", "stab", setdiff(all_traits, c("Troph", "a", "b", "Logarithm.of.must", "Keratin", "stab")),"b", "a", "Troph")

# 将 Trait 设置为因子，并按照手动指定的顺序排列
indval_melt$Trait <- factor(indval_melt$Trait, levels = ordered_traits)
# 对每个组的 IndVal 进行归一化处理
indval_melt <- indval_melt %>%
  group_by(Group) %>%
  mutate(Norm_IndVal = (IndVal - min(IndVal)) / (max(IndVal) - min(IndVal)))

# 绘制热图
# 绘制热图
ggplot(indval_melt, aes(x = Group, y = Trait, fill = Norm_IndVal)) +
  geom_tile() +
  scale_fill_gradientn(colors = c("white", "#f7484f")) +
  labs(title = "Indicator Value of Functional Traits by Group", x = "Group", y = "Functional Trait") +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 10))


# 提取指示性分析结果并保留 3 位小数
indval_data <- round(indval_result[["indval"]], 3)

# 将结果保存为 xlsx 文件
write.xlsx(indval_data, file = "indval_result.xlsx", rowNames = TRUE)





#####################混合效应模型检验#########
# 安装和加载需要的包

library(lme4)
library(readxl)
library(MASS)
library(effects)
library(ggeffects)
library(lattice)
library(glmmTMB)
# 读取数据
##########  HIS7080
data <- read_excel("groupHIS7080.xlsx")
colnames(data)
data$location <- as.factor(data$location)
data$group_ID <- as.factor(data$group_ID)
#Single group level
model_poisson <- glmmTMB(new_NIS_group ~ native+LOI+ lake_area+(1 | group_ID) +(1 | location), family=poisson(link = "sqrt"), data)
summary(model_poisson)

data <- read_excel("two_hyp/1-2 mix_effect/lake_level_LOI/lake_level_HIS7080.xlsx")
colnames(data)
# 确保所有的分类变量都被转换为因子类型
data$location <- as.factor(data$location)

#lake level
model_poisson <- glmmTMB(new_NIS ~ native +LOI+(1 |location), family = nbinom2, data)
summary(model_poisson)

##########  7080NOW
# 读取数据
data <- read_excel("two_hyp/group7080NOW.xlsx")
colnames(data)
data$location <- as.factor(data$location)
data$group_ID <- as.factor(data$group_ID)
#Single group level
model_poisson <- glmmTMB(new_NIS_group ~ native+LOI+(1 | group_ID) +(1 | location), family=poisson(link = "sqrt"), data)
summary(model_poisson)



###########功能组基本信息分析########
# Load required libraries
library(ggplot2)
library(dplyr)
library(readxl)

# Load data from Excel file
species_data <- read_excel("FGs_analysisi.xlsx")

# Summarize the count of FGs per time period
fg_summary <- species_data %>%
  group_by(time, FGs) %>%
  summarise(count = n()) %>%
  ungroup()

# Define desaturated colors for each FG group
fg_colors <- c("#57aae2", "#72d66c", "#f07b7c", "#ffa64e", "#a580cd", "#d78050")
fg_colors_desaturated <- scales::col2hcl(fg_colors, l = 70)  # Reduce saturation by increasing lightness

# Create the stacked bar plot
stacked_bar_plot <- ggplot(fg_summary, aes(x = factor(time, levels = c("Early", "Mid", "Late")), y = count, fill = factor(FGs))) +
  geom_bar(stat = "identity", position = position_stack(vjust = 0)) +  # Ensure bars start from x-axis
  scale_fill_manual(values = fg_colors_desaturated, name = "FGs") +
  labs(title = "Stacked Bar Plot of FGs by Time Period",
       x = "Time Period",
       y = "Count of FGs") +
  theme_minimal() +
  theme(
    panel.grid = element_blank(),  # Remove grid lines
    axis.line = element_line(colour = "black"),  # Add axis lines
    axis.ticks = element_line(colour = "black")  # Add axis ticks
  )

# Display the plot
print(stacked_bar_plot)

# Load required libraries
library(ggplot2)
library(dplyr)
library(readxl)

# Display the plot
print(stacked_bar_plot)



# Load required libraries
library(ggplot2)
library(dplyr)
library(readxl)
library(ggpattern)

# Load data from Excel file
species_data <- read_excel("FGs_analysisi.xlsx")

# Summarize the count of FGs per time period and species type, and calculate percentage
fg_summary <- species_data %>%
  group_by(time, FGs, species) %>%
  summarise(count = n(), .groups = 'drop') %>%
  group_by(time, FGs) %>%
  mutate(percentage = count / sum(count) * 100) %>%
  ungroup()

# Create the stacked bar plot for each time period showing the percentage of species within each FG
stacked_bar_plot <- ggplot(fg_summary, aes(x = factor(FGs), y = percentage, fill = species, pattern = species)) +
  geom_bar_pattern(stat = "identity", position = "stack", width = 0.8,
                   pattern_fill = "gray",
                   pattern_angle = 45,  # Set angle for the stripe pattern
                   pattern_density = 0.005,  # Set higher density for more compact stripes
                   pattern_spacing = 0.08) +
  scale_fill_manual(values = c("native" = "#808080", "non" = "transparent"), name = "Species Type") +  # Correct transparent fill for non-native species
  scale_pattern_manual(values = c("native" = "none", "non" = "stripe")) +
  labs(title = "Percentage Distribution of Species within FGs by Time Period",
       x = "Functional Groups (FGs)",
       y = "Percentage of Species") +
  facet_wrap(~factor(time, levels = c("Early", "Mid", "Late")), ncol = 3) +
  theme_minimal()

# Display the plot
print(stacked_bar_plot)
